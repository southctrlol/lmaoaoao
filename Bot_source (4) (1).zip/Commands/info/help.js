const {
  ComponentType,
  EmbedBuilder,
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
    embedMsg,
    guild,
    name,
} = require("discord.js");
module.exports = {
  premiumOnly: false,
  voteRequired: false,
  data: new SlashCommandBuilder()
    .setName("help")

    .setDescription("Get a list of all the commands from the discord bot."),
  async execute(interaction) {

    const { client } = interaction;

       const voteButton = new ButtonBuilder()
      .setLabel("Vote")
      .setStyle(ButtonStyle.Link)
      .setURL("https://discord.com/invite/Nb3wVDTKVr"); // Replace "your-bot-id" with your actual bot ID

    const supportButton = new ButtonBuilder()
      .setLabel("Support")
      .setStyle(ButtonStyle.Link)
      .setURL("https://discord.com/invite/QRBs9Qxjjy"); // Replace "your-support-server" with your actual support server invite link

  const devbutton = new ButtonBuilder()
	.setLabel("Developer")
	.setStyle(ButtonStyle.Link)
	.setURL("https://discord.com/users/904246540959371295");
      
    const emojis = {
      ai: "<:emoji_43:1169594656095473674>",
      suggestions: "<:emoji_41:1169594625120555018>",
      reactionroles: "<:emoji_44:1169594940595109938>",
      premium: "<:emoji_45:1169595102973403136>",
      info: "<:emoji_62:1169599194986717314>",
      developer: "<:emoji_47:1169595424181600296>",
      economy: "<:emoji_48:1169595596512964699>",
      applications: "<:emoji_56:1169597483962335263>",
      botshop: "<:emoji_50:1169596064370790481>",
      fun: "<:emoji_51:1169596480470913105>",
      giveaways: "<:emoji_52:1169596787770798141>",
      moderation: "<:emoji_59:1169598047844569159>",
      music: "<:emoji_54:1169597126167232512>",
      roles: "<:emoji_55:1169597344308793374> ",
      services: "<:emoji_49:1169595823496118363>",
      suggest: "<:emoji_41:1169594625120555018>",
      ticket: "<:emoji_57:1169597748241248357>",
      videos: "<:emoji_58:1169597951006494780>",
      setup: "<:emoji_56:1169597483962335263>",
      games: "<:emoji_60:1169598176106389584>",
      AntiNuke: "<:emoji_61:1169598323771048016>",
    };

    function getCommand(name) {
      const getCommandID = client.application.commands.cache
        .filter((cmd) => cmd.name === name) // Filter by command name
        .map((cmd) => cmd.id); // Map to just the ID property

      return getCommandID;
    }

    const directories = [
      ...new Set(client.commands.map((cmd) => cmd.folder)),
    ];

    const formatString = (str) =>
      `${str[0].toUpperCase()}${str.slice(1).toLowerCase()}`;

    const categories = directories.map((dir) => {
      const getCommands = client.commands
        .filter((cmd) => cmd.folder === dir)
        .map((cmd) => {
          return {
            name: cmd.data.name,
            description:
             cmd.data.description ||
              " There is no description for this command.",
          };
        });
      return {
        directory: formatString(dir),
        commands: getCommands,
      };
    });
    const embed = new EmbedBuilder()
    .setTitle("Multifunctional Discord bot")
      .setDescription(" Bot is works only with Slash Commands ```ini\n[See lists of commands by selecting a category down below!]```")
   	  .addFields({ name: ' ➜ If you need any help just Contact developer support', value: `Report this with \`/report bug\`` })
    .addFields({ name: ' ➜ Make sure Ryzen has the highest role, its required to secure your server at the highest quality.', value: ` New Commands!
- /Reminder
- /Membercount
So stay tuned for more!` })
      .setColor("#148be5")
      .setImage(`https://share.creavite.co/lXbZibeorBJLhg3U.gif`)
      .setAuthor({ name: `${client.user.username}'s Commands`, iconURL: client.user.avatarURL() })
    const components = (state) => [
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId("help-menu")

          .setPlaceholder("Find a category")
          .setDisabled(state)
          .addOptions(
            categories.map((cmd) => {
              return {
                label: cmd.directory,
                value: cmd.directory.toLowerCase(),
                description: `Commands from ${cmd.directory} category.`,
                emoji: emojis[cmd.directory.toLowerCase() || null],
              };
            })
          )
      ),
        new ActionRowBuilder().addComponents(voteButton, supportButton, devbutton),
    ];
    const initialMessage = await interaction.reply({
      embeds: [embed],
      components: components(false),
    });

    const filter = (interaction) =>
      interaction.user.id === interaction.member.id;

    const collector = interaction.channel.createMessageComponentCollector({
      filter,
      componentType: ComponentType.StringSelect,
    });

    collector.on("collect", (interaction) => {
      const [directory] = interaction.values;
      const category = categories.find(
        (x) => x.directory.toLowerCase() === directory
      );

      const categoryEmbed = new EmbedBuilder()
        .setTitle(`${emojis[directory.toLowerCase() || null]}  ${formatString(directory)} commands`)
        .setImage(`https://share.creavite.co/gwRwN5CjfD7XgKiY.gif`)
        .setDescription(
          `A list of all the commands categorized under ${directory}.`
        )
        .setColor("#148be5")
        .addFields(
          category.commands.map((cmd) => {
            return {
              name: `</${cmd.name}:${getCommand(cmd.name)}>`,
              value: `\`${cmd.description}\``,
              inline: true,
            };
          })
        );

      interaction.update({ embeds: [categoryEmbed] });
    });

    collector.on("end", () => {
      initialMessage.edit({ components: components(true) });
    });
  },
};