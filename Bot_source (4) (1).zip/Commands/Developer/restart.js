const { SlashCommandBuilder, PermissionsBitField } = require('discord.js');

 

module.exports = {

    data: new SlashCommandBuilder()

    .setName('restart')

    .setDMPermission(false)

    .setDescription('Shuts down Ryzen. Only the owner of Ryzen can use this command. Use twice for shutdown.'),

    async execute(interaction, client) {

 

        if (interaction.user.id === `904246540959371295`) {

            await interaction.reply({ content: `**Shutting down..**`, ephemeral: true})

            await client.user.setStatus("invisible")

            process.exit();

        } else {

            return interaction.reply({ content: `Only **the owner** of Ryzen can use this command.`, ephemeral: true})

        }

    }

}