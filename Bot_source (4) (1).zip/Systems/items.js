module.exports = [
    {
        name: "Gift",
        description: "Gift from santa clause open it to get free rewards",
        value: "Gift",
        emoji: "🎁",
        price: "600"
    },
    {
        name: "Christmas-Tree",
        description: "Use this to get random amount of items or money",
        value: "Christmas-Tree",
        emoji: "🎄",
        price: "5000"
    },
    {
        name: "JoyStick",
        description: "A show piece to flex on your freinds",
        value: "JoyStick",
        emoji: "🕹️",
        price: "10000"
    },

]